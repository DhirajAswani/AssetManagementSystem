<?php

class Database
{
    private $host = "localhost";
    private $db_name = "assetmanagementdhiraj";
    private $username = "Dhiraj";
    private $password = "Dhiraj@123";
    private $conn = null;
    
    
    public function __construct()
    {
        try{
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->db_name}",$this->username,$this->password);
        }
        catch(PDOException $e)
        {
            die("Issue : ". $e->getMessage());
        }
    }
    
    
    public function getConnection()
    {
        return $this->conn;
    }
    
}


?>