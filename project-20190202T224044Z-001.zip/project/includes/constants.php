<?php

define("BASEURL","http://localhost/AssetManagementProject/");
define("LAYOUT",BASEURL."project/includes/layouts/");

?>